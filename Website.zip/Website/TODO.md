
## 1. Structure & Tech Setup

- [ ] Decide final tech stack for the business website (pure HTML/CSS/JS, PHP templates, or React/Next.js) and stick to one approach.
- [ ] Clearly separate **Business Website** vs **Car Research App**:
  - [ ] Keep marketing/business site in `Website/`.
  - [ ] Link out to the car research platform (DriveMatrix/product UI) via a “Launch Platform / Beta” button instead of mixing code.
- [ ] Create a clean folder structure inside `Website/`:
  - [ ] `Website/assets/css/` for stylesheets.
  - [ ] `Website/assets/js/` for scripts.
  - [ ] `Website/assets/img/` for logos, illustrations, and screenshots.
  - [ ] `Website/pages/` (or `src/pages/` if using React/Next) for main pages.
  - [ ] `Website/partials/` for shared header, footer, and layout components.
- [ ] Implement a **single shared layout** (header + footer + base structure) as a partial/template and use it across all pages.

---

## 2. Navigation & Page Map

- [ ] Finalize top navigation items:
  - [ ] Home
  - [ ] Solutions
  - [ ] Product Suite / Apps
  - [ ] For Fleets
  - [ ] For Individuals
  - [ ] For Partners
  - [ ] Resources / Blog
  - [ ] About
  - [ ] Contact / Request Demo
- [ ] Ensure all navbar links point to real pages (or clearly marked “Coming soon”).

### 2.1 Home Page

- [ ] Build a **hero section** with:
  - [ ] Clear one-line pitch for Autopredator (unified vehicle intelligence & management).
  - [ ] 2–3 line supporting description.
  - [ ] Primary CTA button (e.g., “Request Demo” or “Join Waitlist”).
- [ ] Add a “Who it’s for” section:
  - [ ] Individuals
  - [ ] Fleet owners / operators
  - [ ] Dealers & brokers
  - [ ] Banks & insurers
- [ ] Add a “Core modules / apps” section:
  - [ ] Fleet Pro
  - [ ] AutoMart
  - [ ] Service & Maintenance
  - [ ] Finance Desk / Loan & Lease Hub
  - [ ] Compliance & Safety
  - [ ] EV Center
  - [ ] Data & Intelligence / Analytics
- [ ] Add a “Key benefits” section (3–4 bullets/cards) highlighting:
  - [ ] Reduced downtime.
  - [ ] Lower operating costs.
  - [ ] Automatic compliance & reminders.
  - [ ] Better data & insights.
- [ ] Add a simple “Vision / Roadmap teaser” section.

### 2.2 Solutions Pages

- [ ] Create `/solutions/individuals` page with:
  - [ ] Problem statement for individual vehicle owners.
  - [ ] How Autopredator solves it.
  - [ ] 3–5 feature highlights.
  - [ ] Use cases.
  - [ ] CTA (Request demo / Join waitlist).
- [ ] Create `/solutions/fleet-owners` page similarly tailored to fleets.
- [ ] Create `/solutions/dealers-and-brokers` page.
- [ ] Create `/solutions/banks-and-insurers` page.

### 2.3 Product Suite / Apps

- [ ] Create a **Product Suite** page listing all key apps as cards:
  - [ ] Fleet Pro
  - [ ] AutoMart
  - [ ] Service & Maintenance
  - [ ] Finance Desk / Loan & Lease Hub
  - [ ] Compliance & Safety
  - [ ] EV Center
  - [ ] Data & Intelligence / Analytics
- [ ] For each app card:
  - [ ] Add icon/illustration.
  - [ ] Add a 1–2 line description.
  - [ ] Add a “Learn more” or “Coming soon” link.

### 2.4 Detailed Product Pages (V2, plan now)

- [ ] Create placeholder detailed pages (even if minimal copy for now):
  - [ ] `/products/fleet-pro`
  - [ ] `/products/automart`
  - [ ] `/products/finance-desk`
  - [ ] `/products/ev-center`
- [ ] Add basic structure (problem, features, screenshots, CTA) for each.

### 2.5 About & Vision

- [ ] Create an **About** page with:
  - [ ] Story of Autopredator.
  - [ ] Vision & mission statements.
  - [ ] “Why now / market gap” explanation.
  - [ ] High-level roadmap (Phase 1, 2, 3).
  - [ ] Short founder section (photo optional).

### 2.6 Contact / Request Demo

- [ ] Create a **Contact / Request Demo** page with form:
  - [ ] Name
  - [ ] Email
  - [ ] Phone
  - [ ] Company / Organization
  - [ ] Fleet size or vehicle use-case (dropdown or input)
  - [ ] Message / Requirements
- [ ] Implement success state (thank-you message or redirect to “Thank you” page).
- [ ] Implement basic validation for required fields.

### 2.7 Resources / Blog

- [ ] Create a **Resources / Blog** page:
  - [ ] Add “Coming soon” message.
  - [ ] Optionally add 1–2 dummy blog cards with placeholder titles & excerpts.

---

## 3. Design System & Branding

- [ ] Define brand identity for Autopredator:
  - [ ] Choose primary color (for CTAs).
  - [ ] Choose accent color.
  - [ ] Choose neutral background/base color.
  - [ ] Choose font pair (headings + body).
- [ ] Implement a **global stylesheet** with:
  - [ ] Typography scale (H1–H6, body, caption).
  - [ ] Button styles (primary, secondary, ghost).
  - [ ] Card styles (padding, border-radius, shadow).
  - [ ] Section spacing (consistent padding/margin).
- [ ] Replace all placeholder/lorem-ipsum text with real Autopredator copy.
- [ ] Ensure layout is responsive:
  - [ ] Mobile-friendly navbar (hamburger if needed).
  - [ ] Sections stack vertically on small screens.
  - [ ] Check readability on phone/tablet/desktop.

---

## 4. Content & Messaging Alignment

- [ ] Review the business plan and extract **core value propositions** for the website.
- [ ] Ensure Home + Solutions pages clearly convey:
  - [ ] Single pane of glass for vehicle operations.
  - [ ] Works across personal, commercial, agricultural, and construction vehicles.
  - [ ] Focus on cost savings, uptime, compliance, safety, and financing.
- [ ] Add a “Who is this for?” section to Home with audience cards.
- [ ] Add specific benefit sections:
  - [ ] “Reduce downtime.”
  - [ ] “Cut hidden vehicle costs.”
  - [ ] “Never miss renewals & compliances.”
  - [ ] “Get more from every vehicle asset.”
- [ ] Add UI screenshots or mockups:
  - [ ] Capture product/DriveMatrix UI screens.
  - [ ] Place screenshots in hero/product sections as static images.

---

## 5. Forms, Backend Hooks & Tracking

- [ ] Implement lead capture across key pages:
  - [ ] CTA on Home hero leads to demo/contact form.
  - [ ] Solutions pages include a mini-form or CTA linking to contact.
- [ ] Decide form handling strategy:
  - [ ] Simple PHP mailer script (if using PHP).
  - [ ] Or third-party form service (Formspree, etc.).
- [ ] Implement clear error handling for forms:
  - [ ] Show messages for missing/invalid fields.
  - [ ] Provide user-friendly success confirmation.
- [ ] Add optional newsletter/waitlist:
  - [ ] Simple email-only input for “Get early access”.
  - [ ] Decide where to store or send these emails (DB or email service).
- [ ] Integrate basic analytics:
  - [ ] Add Google Analytics / Plausible / similar.
  - [ ] Verify tracking of page views and CTA clicks.

---

## 6. SEO, Meta & Performance

- [ ] Set unique `<title>` and `<meta description>` for each page.
- [ ] Use proper heading hierarchy (one H1 per page; logical H2/H3).
- [ ] Add descriptive `alt` text for all key images.
- [ ] Create and serve `robots.txt`.
- [ ] Create and serve `sitemap.xml` with all important URLs.
- [ ] Ensure URLs are clean and readable (avoid messy query strings when possible).
- [ ] Add Open Graph tags to main pages:
  - [ ] `og:title`
  - [ ] `og:description`
  - [ ] `og:image`
  - [ ] `og:url`
- [ ] Optimize images:
  - [ ] Compress large graphics.
  - [ ] Prefer `.webp` where supported.
  - [ ] Lazy-load below-the-fold images.
- [ ] Remove unused CSS/JS from old templates to improve load speed.

---

## 7. Repo Cleanup & Dev Experience

- [ ] Delete unused/demo/template HTML/PHP/JS files that are not part of the final sitemap.
- [ ] Remove old CSS files not referenced anywhere in the site.
- [ ] Standardize file naming:
  - [ ] `index.*` for Home.
  - [ ] `solutions-fleets.*` or `/solutions/fleets/index.*` etc.
  - [ ] `contact.*` for contact page.
- [ ] Add a `README.md` inside `Website/` explaining:
  - [ ] Purpose of this folder (business/marketing site).
  - [ ] Tech stack used.
  - [ ] How to run locally.
  - [ ] How to build (if applicable).
  - [ ] How to deploy.
- [ ] Add simple scripts or documented commands:
  - [ ] For local dev (`npm run dev` / `php -S` / etc.).
  - [ ] For build (`npm run build` etc.) if using a bundler/framework.

---

## 8. Final QA & Deployment

- [ ]test navigation:
  - [ ] All navbar links work.
  - [ ] No dead links in buttons/CTAs.
- [ ] Check for 404s and fix/update routes/links.
- [ ] Test on multiple viewports:
  - [ ] Small phone (~360–400px).
  - [ ] Tablet (~768px).
  - [ ] Desktop (≥1366px).
- [ ] Proofread all visible text:
  - [ ] Fix spelling/grammar.
  - [ ] Ensure consistent naming (“Autopredator”, module names, etc.).
- [ ] Deploy the website to hosting:
  - [ ] Choose hosting (Netlify/Vercel/shared hosting etc.).
  - [ ] Point domain (e.g., `autopredator.in`) to the deployed site.
  - [ ] Verify HTTPS/SSL is working.
- [ ] Do a final live-site check:
  - [ ] Forms submit correctly.
  - [ ] Analytics records visits.
  - [ ] Site loads correctly on mobile & desktop over real internet.

